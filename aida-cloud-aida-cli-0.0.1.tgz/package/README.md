# Aida CLI

Deploys a project to Aida Cloud, and generates the GitHub Actions workflows that do it on every
pull request. Part of the Aida Cloud PoC.

## Run it

Requires Node 24. From the repo root, after `npm install`:

```sh
npx aida --help             # the workspace bin, linked into node_modules/.bin
```

`npm install` builds the CLI first, so the bin is there. To rebuild after a change:

```sh
npm run build -w aida-cli
```

The entry point is TypeScript, but what ships is the JavaScript in `dist/`. Node refuses to
strip types from files under `node_modules`, so an installed copy can only ever run built
output. Running the source directly still works while you are in this repo:

```sh
node aida-cli/src/main.ts --help
```

## Commands

`aida init [--project <id>]` writes `.github/workflows/preview.yaml`, `production.yaml` and
`aida.json` into the current project. It needs a git repository, and it reads the checked-out
branch to decide what production deploys from. It never overwrites, so re-running it is safe; a
file already there is left alone and reported as skipped. The workflows pin the version of the
CLI that wrote them, so a project's deploys do not change under it.

`aida check` verifies those three files: that each workflow parses as YAML with a top-level
`jobs`, and that `aida.json` carries a project id. It reads only the files it owns, so a
workflow of your own in the same directory will not fail it. Exit code is 0 when the project is
ready and 1 when anything is missing or unusable, which is what makes it usable as a CI gate.

`aida deploy` deploys the project and waits for it to serve. It works out which environment to
deploy to, creates the pull request's environment when the project has none, uploads a
`git archive` of HEAD, streams the build log, and prints the URL. Exit code is 0 once the
deployment is live and 1 for anything else.

On a pull request in GitHub Actions it deploys to that pull request's review environment, making
it on the first push and reusing it on every one after. `--environment <id>` deploys to one you
name, and `--production` to the project's production environment, which is what the generated
production workflow uses. Outside a pull request one of those two is required: it will not
guess.

Because the tarball comes from git, a deploy carries exactly what is committed at HEAD: no
`node_modules`, no ignored build output, and no uncommitted work.

| Flag                 | What it does                                                             |
| -------------------- | ------------------------------------------------------------------------ |
| `--environment <id>` | deploy to this environment instead of the pull request's                 |
| `--production`       | deploy to the project's production environment                           |
| `--token <token>`    | the API token, otherwise `AIDA_TOKEN`                                    |
| `--project <id>`     | the project, otherwise `AIDA_PROJECT_ID`, otherwise `aida.json`          |
| `--api <url>`        | the platform, otherwise `AIDA_API_URL`, otherwise `aida.json`            |
| `--json`             | print one JSON object and nothing else                                   |
| `--no-wait`          | return once the upload is accepted                                       |
| `--dry-run`          | resolve the environment and report where it would land, changing nothing |

`aida status` and `aida logs` are declared so `--help` shows the shape they will take, but they
are not built. They exit 1 rather than reporting success for work they did not do.

## Configuration

`aida.json` sits at the project root and is committed:

```json
{
  "projectId": "prj_...",
  "apiUrl": "https://aida-cloud-test.groupone.dev"
}
```

`apiUrl` may be left out, and defaults to `http://localhost:3000`. The token is never read from
this file: it comes from `AIDA_TOKEN` or `--token`, because the file is committed.

Each value is taken from the first place that sets it: the flag, then the environment, then the
file.

## In GitHub Actions

Two secrets. `AIDA_TOKEN` authenticates the deploy, and `AIDA_NPM_TOKEN` is a GitLab deploy
token with `read_package_registry`, which the install step needs because the CLI is published to
group.one's registry rather than the public one. Mint it on the Aida Cloud PoC project under
Settings, Repository, Deploy tokens. When it expires, every pinned workflow fails at install
with a 401 that does not look like an expiry.

On a runner the CLI also records the deployment as step
outputs (`url`, `environment-id`, `release-id`), writes the URL to the step summary, and emits an
error annotation when a deploy fails.

```yaml
- name: Deploy a preview
  id: aida
  run: aida deploy
  env:
    AIDA_TOKEN: ${{ secrets.AIDA_TOKEN }}

- run: echo "Preview at ${{ steps.aida.outputs.url }}"
```

## Try it locally

```sh
npm run build -w aida-cli
AIDA=$PWD/aida-cli/dist/main.js
cd "$(mktemp -d)" && git init -q -b main .

node "$AIDA" check                      # exit 1: nothing is set up
node "$AIDA" init --project prj_demo    # creates both workflows and aida.json
node "$AIDA" check                      # exit 0: checks passed
node "$AIDA" init                       # exit 0: already in place, all skipped
```

A deploy needs a running platform and a token from the console's Tokens tab, which starts with
`aida_`. See `DEPLOYMENT.md` at the repo root for bringing one up.

```sh
AIDA_TOKEN=aida_... AIDA_API_URL=http://localhost:3000 node "$AIDA" deploy --dry-run
```

## Work on it

```sh
npm test -w aida-cli            # vitest; no database, no docker
npm run typecheck -w aida-cli
npm run build -w aida-cli
npm run lint                    # from the root, covers this workspace
npm run format:check
```

Tests run against temp directories from `mkdtemp`. The branch-detection and archive ones shell
out to a real `git`, so git has to be on PATH. One test makes the workflows directory read-only
to prove a failed write doesn't stop the other files from being written; it skips when you are
root, since root ignores the mode.

After an API change, regenerate the client's types from the repo root and commit them:

```sh
npm run openapi && npm run cli:api:generate
```

## Release

```sh
npm run cli:release -- patch|minor|major
```

It refuses a dirty tree, a version already tagged, and an empty `## [Unreleased]` section in
`CHANGELOG.md`. It runs the build, the typecheck and the tests before it writes anything, then
commits and tags `aida-cli/vX.Y.Z` and prints the push command. Pushing is left to you: a tag
is what other repositories pin, and taking one back breaks every workflow that named it.

Pushing the tag is what publishes it: the tag pipeline re-runs the checks, verifies the tag
names the version in the manifest, and publishes `@aida-cloud/aida-cli` to the project's
package registry.
